kernel version should be up to 2.6.X
1.      cp LCDd.conf /etc                     (copy the file to /etc folder) 
2.      tar zxvf lcdproc-0.5.0.tar.gz     (unzip the file, it will product a folder ��lcdproc-0.5.0.tar.gz��)
3.      cd lcdproc-0.5.0
4.      ./configure --enable-drivers=hd44780
5.      make
6.      ./server/LCDd
7.      ./clients/lcdproc/lcdproc

-------
please refer below link if any other questions.

http://lcdproc.sourceforge.net/
Please install as the INSTALL file instructed.
The lcd is HD44780 compatible. The keypad are winamp style wiring.
There are more docs at following URL:
http://lcdproc.sourceforge.net/docs/stable-0-4-x-user-html/c443.html#HD44780-HOWTO
http://lcdproc.sourceforge.net/docs/stable-0-4-x-user-html/x904.html